<?php
/**
 * @package Meteo
 * @version 1.0.0
 */
/*
Plugin Name: NeedWeather
Plugin URI: https://joselitop.promo-93.codeur.online
Description: Plugin pour connaitre la meteo
Author: ACS
Version: 1.0
Author URI: https://joselitop.promo-93.codeur.online
*/

require_once 'Models/Data.php';

register_activation_hook(__FILE__, 'create_database_table');

function create_database_table(){

    global $wpdb;
    
    $sql = "CREATE TABLE " . $wpdb->prefix . "shortcode (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        shortcode VARCHAR(30) NOT NULL);
        CREATE TABLE " . $wpdb->prefix . "communes (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        code INT(6) NOT NULL,
        nom VARCHAR(30)
    )";

    $wpdb->query($sql);
}


register_uninstall_hook(__FILE__, 'delete_database_table');

function delete_database_table(){

    global $wpdb;

    $sql = "DROP TABLE IF EXISTS " . $wpdb->prefix . "shortcode , " . $wpdb->prefix . "communes"; 

    $wpdb->query($sql);
}


add_action('admin_menu','lienDeMenu');

 function lienDeMenu(){
     add_menu_page(
         'La page de mon plugin', //Titre de ma page
         'NeedWeather', //Lien dans le add_menu_page
         'manage_options',
         plugin_dir_path(__FILE__).'includes/plugin-page.php'// L'adresse ou l'on doit attérir quand on clique sur le lien de menu

     );
 }

?>